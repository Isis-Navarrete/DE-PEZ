<?php
/**
 * Plugin Name: Login con Redirección Final
 * Description: Plugin real para login que redirige correctamente a docentes y jefes de carrera usando JavaScript.
 * Version: 2.0
 * Author: Juan Taniz
 */

if (!defined('ABSPATH')) exit;

add_shortcode('login_real', 'login_real_render');

function login_real_render() {
    global $wpdb;

    if (!session_id()) session_start();

    $redireccionJS = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['correo'], $_POST['contrasena'])) {
        $correo = strtolower(trim($_POST['correo']));
        $contrasena = trim($_POST['contrasena']);

        $usuario = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM usuario WHERE correo = %s AND contrasena = %s",
            $correo, $contrasena
        ));

        if ($usuario) {
            $rol = $wpdb->get_var($wpdb->prepare(
                "SELECT id_rol FROM usuariorol WHERE id_usuario = %d LIMIT 1",
                $usuario->id_usuario
            ));

            $_SESSION['usuario_id'] = $usuario->id_usuario;
            $_SESSION['usuario_nombre'] = $usuario->nombre;
            $_SESSION['usuario_rol'] = $rol;

            // Redirección final
            if ($rol == 1) {
                $redireccionJS = "window.location.href = 'https://nonstop-taniz.mnz.dom.my.id/?page_id=32';";
            } elseif ($rol == 3) {
                $redireccionJS = "window.location.href = 'https://nonstop-taniz.mnz.dom.my.id/?page_id=60';";
            } else {
                echo "<div style='color:red;'>⚠️ Este rol aún no tiene acceso definido.</div>";
            }
        } else {
            echo "<div style='color:red;'>❌ Usuario o contraseña incorrectos.</div>";
        }
    }

    ob_start(); ?>
    <form method="POST" style="max-width:400px;margin:auto;border:1px solid #ccc;padding:20px;background:#f9f9f9;">
        <h3 style="text-align:center;">Iniciar Sesión</h3>
        <label for="correo">Correo:</label>
        <input type="email" name="correo" required style="width:100%;padding:8px;"><br><br>

        <label for="contrasena">Contraseña:</label>
        <input type="password" name="contrasena" required style="width:100%;padding:8px;"><br><br>

        <button type="submit" style="width:100%;padding:10px;">Entrar</button>
    </form>
    <?php
    if (!empty($redireccionJS)) {
        echo "<script>$redireccionJS</script>";
    }

    return ob_get_clean();
}
